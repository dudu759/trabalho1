package trabalhodeprogramacao;


public class Course { // classe
    // Atributos com visibilidade privada
    private int codeCourse;
    private String name;
    
    
    // Métodos Get e Set

    public int getCodeCourse() {
        return codeCourse;
    }

    public void setCodeCourse(int codeCourse) {
        this.codeCourse = codeCourse;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
}
