package questaoquatro;
public class Diptera  extends Insecta {

    @Override
    public String obterDescricao() {
        return super.obterDescricao() + "\nDiptera "; 
    }
    
    
    
}
