package questaoquatro;
public class CanisFamiliaris extends Canis {

    @Override
    public String obterDescricao() {
        return super.obterDescricao() + "\nCanis Familiaris"; 
    }
    
    
    
    
}
