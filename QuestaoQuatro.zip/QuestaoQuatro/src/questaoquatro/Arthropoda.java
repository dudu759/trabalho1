package questaoquatro;
public class Arthropoda extends Animalia {

    @Override
    public String obterDescricao() {
        return super.obterDescricao() + "\nArthropoda "; 
    }
    
 
}
