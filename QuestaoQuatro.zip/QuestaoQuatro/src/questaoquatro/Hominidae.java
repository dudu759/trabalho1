package questaoquatro;
public class Hominidae extends Primata {

    @Override
    public String obterDescricao() {
        return super.obterDescricao() + "\nHominidae"; 
    }
    
    
    
    
    
    
}
