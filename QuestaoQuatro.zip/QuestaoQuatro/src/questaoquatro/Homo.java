package questaoquatro;
public class Homo extends Hominidae {

    @Override
    public String obterDescricao() {
        return super.obterDescricao() + "\nHomo"; 
    }
    
    
    
}
