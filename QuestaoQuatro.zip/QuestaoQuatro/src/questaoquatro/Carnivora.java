package questaoquatro;
public class Carnivora extends Mammalia {

    @Override
    public String obterDescricao() {
        return super.obterDescricao() + "\nCarnivora"; 
    }
    
    
    
}
