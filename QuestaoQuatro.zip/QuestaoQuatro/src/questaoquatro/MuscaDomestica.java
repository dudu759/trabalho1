package questaoquatro;
public class MuscaDomestica extends Musca {

    @Override
    public String obterDescricao() {
        return super.obterDescricao() + "\nMusca Domestica";
    }
    
     
    
}
