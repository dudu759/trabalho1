package questaoquatro;
public class Animalia {
    
    public String obterDescricao () {
        return "\nAnimalia";
                        
    }
    
}
