package questaoquatro;
public class Muscidae extends Diptera {

    @Override
    public String obterDescricao() {
        return super.obterDescricao() + "\nMuscidae "; 
    }
    
    
    
}
