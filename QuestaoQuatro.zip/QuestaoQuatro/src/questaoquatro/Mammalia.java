package questaoquatro;
public class Mammalia extends Chordata {

    @Override
    public String obterDescricao() {
        return super.obterDescricao ()  + "\nMammalia" ;
    }
    
    
}
