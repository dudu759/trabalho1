package questaoquatro;
public class HomoSapiens extends Homo {

    @Override
    public String obterDescricao() {
        return super.obterDescricao() + "\nHomo Sapiens"; 
    }
    
    
    
}
