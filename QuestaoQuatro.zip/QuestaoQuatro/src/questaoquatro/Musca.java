package questaoquatro;
public class Musca extends Muscidae {

    @Override
    public String obterDescricao() {
        return super.obterDescricao() + "\nMusca "; 
    }
    
     
    
}
