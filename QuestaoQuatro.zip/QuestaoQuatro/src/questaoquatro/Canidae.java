package questaoquatro;
public class Canidae extends Carnivora {

    @Override
    public String obterDescricao() {
        return super.obterDescricao() + "\nCanidae"; 
    }
    
    
    
}
